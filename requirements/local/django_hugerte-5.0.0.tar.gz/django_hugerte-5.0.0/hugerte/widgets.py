# Copyright (c) 2026 Diego Benitez

"""
This HugeRTE was partially copied and extended from this code by Joost Cassee:
https://github.com/jazzband/django-tinymce
"""

import json
import warnings
from collections import OrderedDict
from pathlib import Path

from django import forms
from django.conf import settings
from django.contrib.admin import widgets as admin_widgets
from django.core.serializers.json import DjangoJSONEncoder
from django.forms.utils import flatatt
from django.utils.html import escape
from django.utils.safestring import mark_safe
from django.utils.translation import get_language, to_locale
from django.utils.translation import gettext as _

import hugerte.settings


class HugeRTE(forms.Textarea):
    """
    HugeRTE widget. Set settings.TINYMCE_JS_URL to set the location of the
    javascript file. Default is "STATIC_URL + 'hugerte/hugerte.min.js'".
    You can customize the configuration with the rte_attrs argument to the
    constructor.

    In addition to the standard configuration you can set the
    'content_language' parameter. It takes the value of the 'language'
    parameter by default.

    In addition to the default settings from settings.TINYMCE_DEFAULT_CONFIG,
    this widget sets the 'language' and 'directionality' parameters by default.
    The first is derived from the current Django language, the second from the
    'content_language' parameter.
    """

    def __init__(self, content_language=None, attrs=None, rte_attrs=None):
        super().__init__(attrs)
        rte_attrs = rte_attrs or {}
        self.rte_attrs = rte_attrs
        self.rte_attrs["strict_loading_mode"] = 1
        self.content_language = content_language

    def use_required_attribute(self, *args):
        # The html required attribute may disturb client-side browser validation.
        return False

    def get_mce_config(self, attrs):
        mce_config = hugerte.settings.DEFAULT_CONFIG.copy()
        if "language" not in mce_config:
            mce_config["language"] = get_language_from_django()
        if mce_config["language"] == "en_US":
            del mce_config["language"]
        else:
            mce_config["language"] = match_language_with_hugerte(mce_config["language"])
        mce_config.update(
            get_language_config(
                self.content_language or mce_config.get("language", "en_US")
            )
        )
        mce_config.update(self.rte_attrs)
        # Assuming that if selector is present, it should include "textarea".
        if not mce_config.get("selector"):
            mce_config["selector"] = f"#{attrs['id']}"
        return mce_config

    def render(self, name, value, attrs=None, renderer=None):
        if value is None:
            value = ""
        final_attrs = self.build_attrs(self.attrs, attrs)
        final_attrs["name"] = name
        if final_attrs.get("class", None) is None:
            final_attrs["class"] = "hugerte"
        else:
            final_attrs["class"] = " ".join(
                [*final_attrs["class"].split(" "), "hugerte"]
            )
        assert "id" in final_attrs, "HugeRTE widget attributes must contain 'id'"
        mce_config = self.get_mce_config(final_attrs)
        mce_json = json.dumps(mce_config, cls=DjangoJSONEncoder)

        final_attrs["data-rte-conf"] = mce_json
        html = [f"<textarea{flatatt(final_attrs)}>{escape(value)}</textarea>"]
        return mark_safe("\n".join(html))  # noqa: S308

    def _media(self):
        css = None

        js = [hugerte.settings.get_js_url()]

        if hugerte.settings.USE_EXTRA_MEDIA:
            if "js" in hugerte.settings.USE_EXTRA_MEDIA:
                js += hugerte.settings.USE_EXTRA_MEDIA["js"]

            if "css" in hugerte.settings.USE_EXTRA_MEDIA:
                css = hugerte.settings.USE_EXTRA_MEDIA["css"]
        js.append("django_hugerte/dist/init_hugerte.js")
        return forms.Media(css=css, js=js)

    media = property(_media)


class AdminHugeRTE(HugeRTE, admin_widgets.AdminTextareaWidget):
    def _media(self):
        css = {
            "all": ["django_hugerte/admin_hugerte.css"],
        }
        return forms.Media(css=css) + super().media

    media = property(_media)


def get_language_from_django():
    language = get_language()
    return to_locale(language) if language is not None else "en_US"


def match_language_with_hugerte(lang):
    """
    Language codes in HugeRTE are inconsistent. E.g. Hebrew is he_IL.js, while
    Danish is da.js. So we apply some heuristic to find a language code
    with an existing HugeRTE translation file.
    """
    if lang.startswith("en"):
        return lang
    # Read hugerte langs from hugerte/static/hugerte/langs/
    tiny_lang_dir = Path(__file__).parent / "static" / "hugerte" / "langs"
    tiny_langs = [
        file_.stem for file_ in tiny_lang_dir.iterdir() if file_.suffix == ".js"
    ]
    if lang in tiny_langs:
        return lang
    if lang[:2] in tiny_langs:
        return lang[:2]
    two_letter_map = {lg[:2]: lg for lg in tiny_langs}
    if lang[:2] in two_letter_map:
        return two_letter_map[lang[:2]]
    warnings.warn(
        f"No HugeRTE language found for '{lang}', defaulting to 'en_US'",
        RuntimeWarning,
        stacklevel=2,
    )
    return "en_US"


def get_language_config(content_language):
    content_language = content_language[:2]

    config = {}
    lang_names = OrderedDict()
    for lang, name in settings.LANGUAGES:
        if lang[:2] not in lang_names:
            lang_names[lang[:2]] = []
        lang_names[lang[:2]].append(_(name))
    sp_langs = []
    for lang, names in lang_names.items():
        default = ""
        if lang == content_language:
            default = "+"

        sp_langs.append(f"{default}{' / '.join(names)}={lang}")

    if content_language in settings.LANGUAGES_BIDI:
        config["directionality"] = "rtl"
    else:
        config["directionality"] = "ltr"

    return config
