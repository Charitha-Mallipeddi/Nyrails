# Copyright (c) 2026 Diego Benitez

"""
This HugeRTE was partially copied and extended from this code by Joost Cassee:
https://github.com/jazzband/django-tinymce
"""

from django.contrib.admin import widgets as admin_widgets
from django.db import models

from hugerte import widgets as hugerte_widgets


class HTMLField(models.TextField):
    """
    A large string field for HTML content. It uses the HugeRTE widget in
    forms.
    """

    def formfield(self, **kwargs):
        defaults = {"widget": hugerte_widgets.HugeRTE}
        defaults.update(kwargs)

        # As an ugly hack, we override the admin widget
        if defaults["widget"] == admin_widgets.AdminTextareaWidget:
            defaults["widget"] = hugerte_widgets.AdminHugeRTE

        return super().formfield(**defaults)
