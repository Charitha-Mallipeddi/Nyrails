django-hugerte
==============

**django-hugerte** is a Django application that contains a widget to render a form field as a HugeRTE editor.
django-tinymce was used as a reference.

It supports Python 3.9+ and Django 4.2 to 5.2. Using HugeRTE 1.0.9.

Quickstart
==========

Install django-hugerte:

.. code-block:: bash

    $ pip install django-hugerte

Add hugerte to INSTALLED_APPS in settings.py for your project:

.. code-block:: python

    INSTALLED_APPS = (
        ...
        'hugerte',
    )


In your code:

.. code-block:: python

    from django.db import models
    from hugerte.models import HTMLField

    class MyModel(models.Model):
        ...
        content = HTMLField()

**django-hugerte** uses staticfiles so everything should work as expected, different use cases (like using widget instead of HTMLField) and other stuff is available in documentation.


License
=======

This program is licensed under the MIT License (see LICENSE.txt)
